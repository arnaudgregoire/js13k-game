(()=>{var e={12:e=>{function t(e,t,n){return{x:Math.floor(e.x+(t.x-e.x)*n),y:Math.floor(e.y+(t.y-e.y)*n)}}e.exports={renderCanvas:function(e,n){let o=document.getElementById("cocktail");if(o){let n=o.getContext("2d"),i=new Image;const c=100,r=50,s={x:100,y:50},a={x:0,y:0},l={x:76,y:0},u={x:38,y:38};i.onload=()=>{n.drawImage(i,s.x,s.y),e.forEach(((e,o)=>{n.fillStyle=e.color,n.beginPath();let i=t(u,a,Math.min(1,.1*o)),d=t(u,l,Math.min(1,.1*o)),p=t(u,a,Math.min(1,.1*(o+1))),y=t(u,l,Math.min(1,.1*(o+1)));n.moveTo(i.x+s.x,i.y+s.y),n.lineTo(p.x+s.x,p.y+s.y),n.lineTo(y.x+c,y.y+r),n.lineTo(d.x+c,d.y+r),n.fill()}))},i.src="assets/cocktail.png"}}}},231:e=>{e.exports={INGREDIENTS:{ABSINTHE:{keyCode:65,key:"A",color:"#76b583",name:"Absinthe"},BACARDI:{keyCode:66,key:"B",color:"#9D702E",name:"Bacardi"},Campari:{keyCode:67,key:"C",color:"#B60000",name:"Campari"}}}}},t={};function n(o){var i=t[o];if(void 0!==i)return i.exports;var c=t[o]={exports:{}};return e[o](c,c.exports,n),c.exports}(()=>{"use strict";function e([e,...t],...n){return n.reduce(((e,n)=>e.concat(n,t.shift())),[e]).filter((e=>null!=e)).join("")}var t=n(231);const o={timer:"00:00",gold:0,customers:[],sentence:"'a green Zoltan please, im thirsty'",ingredients:[],decorations:[],recipe:{title:"'The Green Zoltan'",content:"2x Acanthe, 2x Qarus, 1x Fireweed"}},{attach:i,connect:c,dispatch:r}=function(e){let t=e();const n=new Map,o=new Map;function i(){for(const[e,i]of n){const n=i();if(n!==o.get(e)){o.set(e,n),e.innerHTML=n;const i=new CustomEvent("render",{detail:t});e.dispatchEvent(i)}}}return{attach(e,t){n.set(t,e),i()},connect:e=>(...n)=>e(t,...n),dispatch(n,...o){t=e(t,n,o),i()}}}((function(e,n,i){console.group(n),console.log("Previous State",e),console.log("Action Arguments",i);const c=function(e=o,n,i){switch(n){case"CHANGE_TIMER":const[n]=i;return Object.assign({},e,{timer:n});case"CHANGE_GOLD":{const[t]=i;return Object.assign({},e,{gold:t})}case"ADD_CUSTOMER":{const{customers:t}=e,[n]=i;return Object.assign({},e,{customers:[...t,n]})}case"REMOVE_CUSTOMER":{const{customers:t}=e,[n]=i;return Object.assign({},e,{customers:[...t.slice(0,n),...t.slice(n+1)]})}case"KEY_PRESSED":{const{ingredients:n}=e,[o]=i;let c;if(Object.keys(t.INGREDIENTS).forEach((e=>{o==t.INGREDIENTS[e].keyCode&&(c=t.INGREDIENTS[e])})),c)return Object.assign({},e,{ingredients:[...n,c]})}default:return e}}(e,n,i);return console.log("Next State",c),console.groupEnd(),c}));function s(t,n){return e`
        <li>
            <p>name:${t.name}</p>
            <p>type:${t.type}</p>
            <p>index:${n}</p>
        </li>
    `}window.dispatch=r;const a=c((function(t){const{customers:n}=t;return e`
        <div>
            <h2>Customers</h2>
            <ul>
                ${n.map(s)}
            </ul>
        </div>
    `})),l=c((function(t){const{gold:n}=t;return e`
        <p>Gold :${n}</p>
    `})),u=c((function(t){const{timer:n}=t;return e`
        <p>Time :${n}</p>
    `})),d=c((function(t){const{recipe:n}=t;return e`
        <div>
            <p>title:${n.title}</p>
            <p>content:${n.content}</p>
        </div>
    `}));function p(t,n){return e`
        <li>
            <p style="color:${t.color}">${t.name}</p>
        </li>
    `}const y=c((function(t){const{ingredients:n}=t;return e`
        <ul style='display:flex; list-style-type:none'>
            ${n.map(p)}
        </ul>
        <canvas id="cocktail" style="height:600px; border: 1px solid; image-rendering: crisp-edges;"></canvas>
    `})),f=c((function(t){const{recipe:n,sentence:o,cocktail:i}=t;return e`
        <div style='display:flex; justify-content:space-between;flex-flow:column;'>
            <h3>${o}</h3>
            ${y(i)}
            ${d(n)}
        </div>
    `}));function m(n,o){return e`
        <li>
            <p>${t.INGREDIENTS[n].key}: ${t.INGREDIENTS[n].name} </p>
        </li>
    `}var E=n(12);i((function(){return e`
        <div style='height:100%; font-family:Verdana; color:white; background-color:black'>
            <div style='display:flex; justify-content:space-even;'>
                ${u()}
                ${l()}
            </div>
            <div style='display:flex; justify-content:space-between; height:90%;'>
                ${a()}
                ${f()}
                ${e`
    <div>
        <h2>Controls</h2>
        <ul>
            ${Object.keys(t.INGREDIENTS).map(m)}
        </ul>
    </div>
    `}
            </div>
        </div>
    `}),document.querySelector("#root")),window.addEventListener("keydown",(e=>{dispatch("KEY_PRESSED",e.keyCode)})),document.querySelector("#root").addEventListener("render",(function(e){const{ingredients:t,decorations:n}=e.detail;t&&(0,E.renderCanvas)(t,n)}))})()})();