(()=>{var t={231:t=>{t.exports={CONTROLS:{73:"Iris",80:"Poppy",82:"Rose",84:"Tulip"}}}},e={};function n(o){var s=e[o];if(void 0!==s)return s.exports;var i=e[o]={exports:{}};return t[o](i,i.exports,n),i.exports}(()=>{"use strict";function t([t,...e],...n){return n.reduce(((t,n)=>t.concat(n,e.shift())),[t]).filter((t=>null!=t)).join("")}var e=n(231);const o={timer:"00:00",gold:0,customers:[],sentence:"'a green Zoltan please, im thirsty'",composition:[],recipe:{title:"'The Green Zoltan'",content:"2x Acanthe, 2x Qarus, 1x Fireweed"}},{attach:s,connect:i,dispatch:c}=function(t){let e=t();const n=new Map,o=new Map;function s(){for(const[t,s]of n){const n=s();if(n!==o.get(t)){o.set(t,n),t.innerHTML=n;const s=new CustomEvent("render",{detail:e});t.dispatchEvent(s)}}}return{attach(t,e){n.set(e,t),s()},connect:t=>(...n)=>t(e,...n),dispatch(n,...o){e=t(e,n,o),s()}}}((function(t,n,s){console.group(n),console.log("Previous State",t),console.log("Action Arguments",s);const i=function(t=o,n,s){switch(n){case"CHANGE_TIMER":const[n]=s;return Object.assign({},t,{timer:n});case"CHANGE_GOLD":{const[e]=s;return Object.assign({},t,{gold:e})}case"ADD_CUSTOMER":{const{customers:e}=t,[n]=s;return Object.assign({},t,{customers:[...e,n]})}case"REMOVE_CUSTOMER":{const{customers:e}=t,[n]=s;return Object.assign({},t,{customers:[...e.slice(0,n),...e.slice(n+1)]})}case"KEY_PRESSED":{const{composition:n}=t,[o]=s,i=e.CONTROLS[o];if(i)return Object.assign({},t,{composition:n.concat({name:i,position:parseInt(10*Math.random())})})}default:return t}}(t,n,s);return console.log("Next State",i),console.groupEnd(),i}));function r(e,n){return t`
        <li>
            <p>name:${e.name}</p>
            <p>type:${e.type}</p>
            <p>index:${n}</p>
        </li>
    `}window.dispatch=c;const a=i((function(e){const{customers:n}=e;return t`
        <div>
            <h2>Customers</h2>
            <ul>
                ${n.map(r)}
            </ul>
        </div>
    `})),l=i((function(e){const{gold:n}=e;return t`
        <p>Gold :${n}</p>
    `})),p=i((function(e){const{timer:n}=e;return t`
        <p>Time :${n}</p>
    `})),u=i((function(e){const{recipe:n}=e;return t`
        <div>
            <p>title:${n.title}</p>
            <p>content:${n.content}</p>
        </div>
    `}));function d(e,n){return t`
        <li>
            <img src="assets/${e.name}.png" style="image-rendering: crisp-edges; height:400px; position:absolute; left:${40+e.position}%; top:30%;">
        </li>
    `}const m=i((function(e){const{recipe:n,sentence:o,composition:s}=e;return t`
        <div style='display:flex; justify-content:space-between;flex-flow:column;'>
            <h3>${o}</h3>
            <ul style="list-style-type:none;">
                ${s.map(d)}
            </ul>
            ${u(n)}
        </div>
    `}));function f(e,n){return t`
        <li>
            <p>${e[0].toUpperCase()}: ${e} </p>
        </li>
    `}s((function(){return t`
        <div style='height:100%; font-family:Verdana; color:white; background-color:black'>
            <div style='display:flex; justify-content:space-even;'>
                ${p()}
                ${l()}
            </div>
            <div style='display:flex; justify-content:space-between; height:90%;'>
                ${a()}
                ${m()}
                ${t`
    <div>
        <h2>Controls</h2>
        <ul>
            ${Object.values(e.CONTROLS).map(f)}
        </ul>
    </div>
    `}
            </div>
        </div>
    `}),document.querySelector("#root")),setInterval((()=>{dispatch("CHANGE_TIMER",(100*Math.random()).toFixed(2))}),1e3),setInterval((()=>{dispatch("CHANGE_GOLD",parseInt(100*Math.random()))}),1500),setInterval((()=>{dispatch("ADD_CUSTOMER",{type:`TYPE_${parseInt(10*Math.random())}`,name:Math.random().toString(36).replace(/[^a-z]+/g,"").substr(0,5)})}),5e3),setInterval((()=>{dispatch("REMOVE_CUSTOMER",0)}),12500),window.addEventListener("keydown",(t=>{console.log(t),dispatch("KEY_PRESSED",t.keyCode)}))})()})();