(()=>{"use strict";function t([t,...n],...e){return e.reduce(((t,e)=>t.concat(e,n.shift())),[t]).filter((t=>null!=t)).join("")}const n=document.createElement("template"),e={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"};function c(t){return n.innerHTML=t,n.content.textContent.replace(/[&<>"']/g,(t=>e[t]))}const o={input_value:"",tasks:[],archive:[]},{attach:s,connect:i,dispatch:u}=function(t){let n=t();const e=new Map,c=new Map;function o(){for(const[t,o]of e){const e=o();if(e!==c.get(t)){c.set(t,e),t.innerHTML=e;const o=new CustomEvent("render",{detail:n});t.dispatchEvent(o)}}}return{attach(t,n){e.set(n,t),o()},connect:t=>(...e)=>t(n,...e),dispatch(e,...c){n=t(n,e,c),o()}}}((function(t,n,e){console.group(n),console.log("Previous State",t),console.log("Action Arguments",e);const s=function(t=o,n,e){switch(n){case"CHANGE_INPUT":{const[n]=e;return Object.assign({},t,{input_value:c(n)})}case"ADD_TASK":{const{tasks:n,input_value:e}=t;return Object.assign({},t,{tasks:[...n,e],input_value:""})}case"COMPLETE_TASK":{const{tasks:n,archive:c}=t,[o]=e,s=n[o];return Object.assign({},t,{tasks:[...n.slice(0,o),...n.slice(o+1)],archive:[...c,s]})}default:return t}}(t,n,e);return console.log("Next State",s),console.groupEnd(),s}));function r(n,e){return t`
        <li>
            ${n}
            <button
                onclick="dispatch('COMPLETE_TASK', ${e})">
                Mark As Done</button>
        </li>
    `}window.dispatch=u;const a=i((function(n){const{tasks:e}=n;return t`
        <h2>My Active Tasks</h2>
        <ul>
            ${e.map(r)}
            <li>
                ${t`
        <input type="text" placeholder="Type here…"
            onchange="dispatch('CHANGE_INPUT', this.value)">
        <button onclick="dispatch('ADD_TASK')">Add</button>
    `}
            </li>
        </ul>
    `}));function l(n){return t`
        <li style="color:#666; text-decoration:line-through">
            ${n}
        </li>
    `}const p=i((function(n){const{archive:e}=n;return t`
        <h2>Completed Tasks</h2>
        <ul>
            ${e.map(l)}
        </ul>
    `}));s((function(n){return t`
        ${a()}
        ${p()}
    `}),document.querySelector("#root"))})();