(()=>{"use strict";function t([t,...e],...n){return n.reduce(((t,n)=>t.concat(n,e.shift())),[t]).filter((t=>null!=t)).join("")}const e={timer:"00:00",gold:0,customers:[],sentence:"'a green Zoltan please, im thirsty'",composition:[],recipe:{title:"'The Green Zoltan'",content:"2x Acanthe, 2x Qarus, 1x Fireweed"}},n={65:"Acanthe",66:"Baethus",67:"Copea"},{attach:o,connect:s,dispatch:c}=function(t){let e=t();const n=new Map,o=new Map;function s(){for(const[t,s]of n){const n=s();if(n!==o.get(t)){o.set(t,n),t.innerHTML=n;const s=new CustomEvent("render",{detail:e});t.dispatchEvent(s)}}}return{attach(t,e){n.set(e,t),s()},connect:t=>(...n)=>t(e,...n),dispatch(n,...o){e=t(e,n,o),s()}}}((function(t,o,s){console.group(o),console.log("Previous State",t),console.log("Action Arguments",s);const c=function(t=e,o,s){switch(o){case"CHANGE_TIMER":const[e]=s;return Object.assign({},t,{timer:e});case"CHANGE_GOLD":{const[e]=s;return Object.assign({},t,{gold:e})}case"ADD_CUSTOMER":{const{customers:e}=t,[n]=s;return Object.assign({},t,{customers:[...e,n]})}case"REMOVE_CUSTOMER":{const{customers:e}=t,[n]=s;return Object.assign({},t,{customers:[...e.slice(0,n),...e.slice(n+1)]})}case"KEY_PRESSED":{const{composition:e}=t,[o]=s,c=n[o];if(c)return Object.assign({},t,{composition:e.concat(c)})}default:return t}}(t,o,s);return console.log("Next State",c),console.groupEnd(),c}));function i(e,n){return t`
        <li>
            <p>name:${e.name}</p>
            <p>type:${e.type}</p>
            <p>index:${n}</p>
        </li>
    `}window.dispatch=c;const r=s((function(e){const{customers:n}=e;return t`
        <div>
            <h2>Customers</h2>
            <ul>
                ${n.map(i)}
            </ul>
        </div>
    `})),a=s((function(e){const{gold:n}=e;return t`
        <p>Gold :${n}</p>
    `})),p=s((function(e){const{timer:n}=e;return t`
        <p>Time :${n}</p>
    `})),u=s((function(e){const{recipe:n}=e;return t`
        <div>
            <p>title:${n.title}</p>
            <p>content:${n.content}</p>
        </div>
    `}));function d(e,n){return t`
        <li>
            <p>name:${e}</p>
            <p>index:${n}</p>
        </li>
    `}const l=s((function(e){const{recipe:n,sentence:o,composition:s}=e;return t`
        <div>
            <h3>${o}</h3>
            <ul>
                ${s.map(d)}
            </ul>
            ${u(n)}
        </div>
    `}));o((function(){return t`
        <div style='margin: 0px; padding: 0px; width:100%;'>
            <div style='display:flex; justify-content:space-even;'>
                ${p()}
                ${a()}
            </div>
            <div style='display:flex; justify-content:space-between;'>
                ${r()}
                ${l()}
                <div>
                    <h3>Controls</h3>
                    <p>A: Acanthe</p>
                    <p>B: Baethus</p>
                    <p>C: Copea</p>
                </div>
            </div>
        </div>
    `}),document.querySelector("#root")),setInterval((()=>{dispatch("CHANGE_TIMER",(100*Math.random()).toFixed(2))}),1e3),setInterval((()=>{dispatch("CHANGE_GOLD",parseInt(100*Math.random()))}),1500),setInterval((()=>{dispatch("ADD_CUSTOMER",{type:`TYPE_${parseInt(10*Math.random())}`,name:Math.random().toString(36).replace(/[^a-z]+/g,"").substr(0,5)})}),5e3),setInterval((()=>{dispatch("REMOVE_CUSTOMER",0)}),12500),window.addEventListener("keydown",(t=>{console.log(t),dispatch("KEY_PRESSED",t.keyCode)}))})();